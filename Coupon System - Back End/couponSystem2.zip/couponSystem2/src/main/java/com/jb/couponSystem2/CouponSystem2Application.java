package com.jb.couponSystem2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponSystem2Application {

	public static void main(String[] args) {
		SpringApplication.run(CouponSystem2Application.class, args);
	}

}
